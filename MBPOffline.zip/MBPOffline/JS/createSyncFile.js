// Navigation Controller

const navigationController = new NavigationController();
navigationController.present( new FilesPickerViewController() );
